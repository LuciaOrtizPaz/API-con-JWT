package com.api.school.service;

import com.api.school.User;
import com.api.school.dto.UserDto;
import com.api.school.service.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @InjectMocks
    private UserService userService;

    @Mock
    private UserRepository userRepository;
    @Test
    public void buscarTodosDebeFuncionar() {
        User user1 = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);
        User user2 = new User("2", "Jhon", 19, 3333333, "jhon@email.com", "password", null);

        when(userRepository.findAll()).thenReturn(List.of(user1, user2));

        List<UserDto> users = userService.getAll();

        assertNotNull(users);
        assertEquals(2, users.size());
        assertEquals("Jose", users.get(0).getName());
        assertEquals("Jhon", users.get(1).getName());
    }
    @Test
    public void buscarPorIdDebeFuncionar() {
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.findById("1")).thenReturn(Optional.of(user));

        UserDto userDto = userService.getById("1");

        assertNotNull(userDto);
        assertEquals("1", userDto.getId());
        assertEquals("Jose", userDto.getName());
        assertEquals(18, userDto.getAge());
        assertEquals(2222222, userDto.getTell());
        assertEquals("jose@email.com", userDto.getEmail());
    }
    @Test
    public void buscarPorIdNoExistenteDebeRetornarNulo() {
        when(userRepository.findById("1")).thenReturn(Optional.empty());

        UserDto userDto = userService.getById("1");

        assertNull(userDto);
    }
    @Test
    public void buscarPorEmailDebeFuncionar() {
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.findByEmail("jose@email.com")).thenReturn(Optional.of(user));

        UserDto userDto = userService.getByEmail("jose@email.com");

        assertNotNull(userDto);
        assertEquals("1", userDto.getId());
    }
    @Test
    public void buscarTodosDebeRetornarListaVaciaSiNoHayUsuarios() {
        when(userRepository.findAll()).thenReturn(List.of());

        List<UserDto> users = userService.getAll();

        assertNotNull(users);
        assertTrue(users.isEmpty());
    }
    @Test
    public void guardarDebeFuncionar() {
        UserDto userDto = new UserDto(null, "Jose", 18, 2222222, "jose@email.com", "password", null);
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.save(any(User.class))).thenReturn(user);

        UserDto savedUserDto = userService.save(userDto);

        assertNotNull(savedUserDto);
        assertEquals("1", savedUserDto.getId());
        assertEquals("Jose", savedUserDto.getName());
        assertEquals(18, savedUserDto.getAge());
        assertEquals(2222222, savedUserDto.getTell());
        assertEquals("jose@email.com", savedUserDto.getEmail());
    }
    @Test
    public void guardarUsuarioConIdNoDebeSobrescribir() {
        UserDto userDto = new UserDto("1", "Jose", 18, 2222222, "jose@email.com", "password", null);
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.save(any(User.class))).thenReturn(user);

        UserDto savedUserDto = userService.save(userDto);

        assertNotNull(savedUserDto);
        assertEquals("1", savedUserDto.getId());
    }
    @Test
    public void guardarUsuarioDebeValidarCampos() {
        UserDto userDto = new UserDto(null, "", -1, 0, "", "", null);

        UserDto savedUserDto = userService.save(userDto);

        assertNull(savedUserDto);
    }
    @Test
    public void guardarDebeManejarExcepcion() {
        UserDto userDto = new UserDto(null, "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.save(any(User.class))).thenThrow(new RuntimeException("Database error"));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.save(userDto);
        });

        assertEquals("Database error", exception.getMessage());
    }
    @Test
    public void guardarDebeFuncionarConFecha() {
        UserDto userDto = new UserDto(null, "Jose", 18, 2222222, "jose@email.com", "password", null);
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.save(any(User.class))).thenReturn(user);

        UserDto savedUserDto = userService.save(userDto);

        assertNotNull(savedUserDto);
        assertEquals("2023-01-01", savedUserDto.getCreatedAt());
    }
    @Test
    public void actualizarDebeFuncionar() {
        UserDto userDto = new UserDto(null, "Jose", 18, 2222222, "jose@email.com", "password", null);
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.findById("1")).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenReturn(user);

        UserDto updatedUserDto = userService.update(userDto, "1");

        assertNotNull(updatedUserDto);
        assertEquals("1", updatedUserDto.getId());
        assertEquals("Jose", updatedUserDto.getName());
        assertEquals(18, updatedUserDto.getAge());
        assertEquals(2222222, updatedUserDto.getTell());
        assertEquals("jose@email.com", updatedUserDto.getEmail());
    }
    @Test
    public void actualizarUsuarioNoExistenteDebeRetornarNulo() {
        UserDto userDto = new UserDto(null, "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.findById("1")).thenReturn(Optional.empty());

        UserDto updatedUserDto = userService.update(userDto, "1");

        assertNull(updatedUserDto);
    }
    @Test
    public void actualizarUsuarioDebeValidarCampos() {
        UserDto userDto = new UserDto(null, "", -1, 0, "", "", null);
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.findById("1")).thenReturn(Optional.of(user));

        UserDto updatedUserDto = userService.update(userDto, "1");

        assertNull(updatedUserDto);
    }
    @Test
    public void actualizarDebeManejarExcepcion() {
        UserDto userDto = new UserDto(null, "Jose", 18, 2222222, "jose@email.com", "password", null);
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.findById("1")).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenThrow(new RuntimeException("Database error"));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.update(userDto, "1");
        });

        assertEquals("Database error", exception.getMessage());
    }
    @Test
    public void actualizarDebeFuncionarConFecha() {
        UserDto userDto = new UserDto(null, "Jose", 18, 2222222, "jose@email.com", "password", null);
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.findById("1")).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenReturn(user);

        UserDto updatedUserDto = userService.update(userDto, "1");

        assertNotNull(updatedUserDto);
        assertEquals("2023-01-01", updatedUserDto.getCreatedAt());
    }
    @Test
    public void eliminarDebeFuncionar() {
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.findById("1")).thenReturn(Optional.of(user));

        boolean result = userService.delete("1");

        assertTrue(result);
        verify(userRepository, times(1)).deleteById("1");
    }
    @Test
    public void eliminarUsuarioNoExistenteDebeRetornarFalso() {
        when(userRepository.findById("1")).thenReturn(Optional.empty());

        boolean result = userService.delete("1");

        assertFalse(result);
        verify(userRepository, times(0)).deleteById("1");
    }
    @Test
    public void eliminarDebeManejarExcepcion() {
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.findById("1")).thenReturn(Optional.of(user));
        doThrow(new RuntimeException("Database error")).when(userRepository).deleteById("1");

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.delete("1");
        });

        assertEquals("Database error", exception.getMessage());
    }
    @Test
    public void eliminarUsuarioDebeVerificarEliminacion() {
        User user = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);

        when(userRepository.findById("1")).thenReturn(Optional.of(user));

        boolean result = userService.delete("1");

        assertTrue(result);
        verify(userRepository, times(1)).deleteById("1");
        verify(userRepository, times(1)).findById("1");
    }
    @Test
    public void eliminarUsuarioDebeActualizarListaDeUsuarios() {
        User user1 = new User("1", "Jose", 18, 2222222, "jose@email.com", "password", null);
        User user2 = new User("2", "Jhon", 19, 3333333, "jhon@email.com", "password", null);

        when(userRepository.findAll()).thenReturn(List.of(user1, user2));
        when(userRepository.findById("1")).thenReturn(Optional.of(user1));

        boolean result = userService.delete("1");

        assertTrue(result);
        verify(userRepository, times(1)).deleteById("1");

        List<UserDto> users = userService.getAll();

        assertNotNull(users);
        assertEquals(1, users.size());
        assertEquals("2", users.get(0).getId());
    }


}



